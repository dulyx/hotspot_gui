#include <iostream>
#include <stdio.h>
#include "../flp.h"
#include "../temperature.h"

using namespace std;

int main()
{
  cout << "Hello world!" << endl;
  return 0;
}

return 
